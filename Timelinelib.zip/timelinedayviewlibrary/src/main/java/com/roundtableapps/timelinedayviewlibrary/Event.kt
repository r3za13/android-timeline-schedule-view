package com.roundtableapps.timelinedayviewlibrary

/**
 * @author Moosa_Abedini
 * @since 18/11/18
 */
open class Event {
    var title: String = ""
    var startTime = 0f
    var endTime = 0f

}