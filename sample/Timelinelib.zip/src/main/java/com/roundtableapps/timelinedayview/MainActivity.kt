package com.roundtableapps.timelinedayview

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.roundtableapps.timelinedayviewlibrary.Event
import com.roundtableapps.timelinedayviewlibrary.EventView
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        btnAdd.setOnClickListener {
            timeLine.addView(EventView(this, Event().apply {
                title = "hello How Are you"
                when {
                    System.currentTimeMillis().toInt()%3==0 -> {
                        startTime = (Math.abs(Random(System.currentTimeMillis()).nextInt() % 4)).toFloat()
                        endTime = (Math.abs(Random(System.currentTimeMillis()).nextInt() % 4)).toFloat() + 4
                    }
                    System.currentTimeMillis().toInt()%3==1 -> {
                        startTime = (Math.abs(Random(System.currentTimeMillis()).nextInt() % 8)).toFloat() + 4
                        endTime = startTime + (Math.abs(Random(System.currentTimeMillis()).nextInt() % 2)).toFloat()
                    }
                    else -> {
                        startTime = (Math.abs(Random(System.currentTimeMillis()).nextInt() % 8)).toFloat() + 4
                        endTime = startTime + (Math.abs(Random(System.currentTimeMillis()).nextInt() % 2)).toFloat()
                    }
                }
                timeLine.post {
                    timeLine.requestLayout()
                    Log.d("HEIGHT", timeLine.height.toString())
                }
            }))
        }


    }
}
